gcc client.c -lm -o client -pthread
gcc server.c -o server